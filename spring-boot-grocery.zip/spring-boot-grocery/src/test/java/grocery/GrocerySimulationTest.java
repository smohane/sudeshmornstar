package grocery;


import static org.junit.Assert.assertEquals;

import java.net.URL;

import org.junit.Test;

import com.grocery.store.GroceryFileReader;
import com.grocery.store.GroceryMain;
import com.grocery.store.RegisterUtility;


public class GrocerySimulationTest {

    @Test
    public void test() {
        String[] path = {"input1.txt","input2.txt","input3.txt","input4.txt","input5.txt"};
        int[] actualTime={7,13,6,9,11};
        for (int i = 0; i < path.length; i++) {
            String input=path[i];
            URL url = this.getClass().getResource(input);
            GroceryMain groceryMain = GroceryFileReader.parseFlatFile(url.getFile());
            RegisterUtility registerUtility = groceryMain.getRegisterUtility();
            int time = GroceryMain.calculateTime(registerUtility,groceryMain);
            testHelper(time,actualTime[i]);
        }
    }

    public void testHelper(int expectedTime,int actualTime) {
        assertEquals(expectedTime, actualTime);
    }

    
    @Test
    public void testSingleFile() {
    	URL url = this.getClass().getResource("single.txt");
        GroceryMain groceryMain = GroceryFileReader.parseFlatFile(url.getFile());
        RegisterUtility registerUtility = groceryMain.getRegisterUtility();
        int time = GroceryMain.calculateTime(registerUtility,groceryMain);
        assertEquals(time, 5);
    }
}
