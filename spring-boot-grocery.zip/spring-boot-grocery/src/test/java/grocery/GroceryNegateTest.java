package grocery;

import static org.junit.Assert.assertEquals;

import java.net.URL;

import org.junit.Rule;
import org.junit.Test;
import org.junit.contrib.java.lang.system.ExpectedSystemExit;

import com.grocery.store.GroceryFileReader;
import com.grocery.store.GroceryMain;

public class GroceryNegateTest {

	@Rule
    public final ExpectedSystemExit exit = ExpectedSystemExit.none();
	
	@Test
	public void wrongFilePath() {
		GroceryMain groceryMain = GroceryFileReader.parseFlatFile("a");
		assertEquals(groceryMain, null);
	}
	
	@Test
	public void wrongCustomerType() {
        URL url = this.getClass().getResource("custtest.txt");
        exit.expectSystemExitWithStatus(-1);
        GroceryFileReader.parseFlatFile(url.getFile());
	}
	
	@Test
	public void wrongFileStructure() {
        URL url = this.getClass().getResource("wrongfile.txt");
        exit.expectSystemExitWithStatus(-1);
        GroceryFileReader.parseFlatFile(url.getFile());
	}
}
