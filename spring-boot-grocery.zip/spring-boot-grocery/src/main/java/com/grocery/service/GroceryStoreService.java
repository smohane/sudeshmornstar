package com.grocery.service;

import org.springframework.stereotype.Service;

import com.grocery.store.GroceryMain;

@Service
public class GroceryStoreService {

    public void launchGrocery(String args[]) {
    	GroceryMain.launchGrocery(args);
    }
}
