package com.grocery.store;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.LineIterator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * @author Sudesh M
 *
 */
public class GroceryFileReader {


	private static final Logger log  = LoggerFactory.getLogger(GroceryFileReader.class);

	/**
	 * @param filePath
	 */
	public static GroceryMain parseFlatFile(String filePath) {
		
		File theFile = new File(filePath);
		GroceryMain groceryMain = null;
		LineIterator it;
		if(theFile.exists()) {
			try {
				String line;
				int firstLine = 0;
				RegisterUtility registerUtility = null;
				it = FileUtils.lineIterator(theFile, "UTF-8");
				while (it.hasNext()) {
					line = it.nextLine();
					if (firstLine == 0) {
						try {
							int noofRegisters = Integer.parseInt(line);
							registerUtility = new RegisterUtility(noofRegisters);
						} catch (NumberFormatException e) {
							log.error("Error in parsing number of registers-> {}",line);
							log.debug("",e);
							System.exit(-1);
						}
					} else {
						Customer customer = GroceryHelper.buildCustomerObjects(line);
						GroceryHelper.customerQueue.add(customer);
					}
					firstLine++;

				}

				groceryMain = new GroceryMain(registerUtility);

			} catch (IOException e) {
				e.printStackTrace();
			}
		}else {
			log.error("File doesn't exists at specified location {}",filePath);
		}
		return groceryMain;
	}
}
