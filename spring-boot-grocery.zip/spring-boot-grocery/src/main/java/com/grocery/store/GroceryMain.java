package com.grocery.store;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.Queue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Sudesh M
 *
 */
public class GroceryMain {

	private static final Logger log  = LoggerFactory.getLogger(GroceryMain.class);
	private static Queue<Customer> customerQueue = new LinkedList<Customer>();
	
	RegisterUtility groceryUtility = null;
	
	public GroceryMain(RegisterUtility groceryUtility) {
        this.groceryUtility = groceryUtility;
    }
	
	public RegisterUtility getRegisterUtility() {
        return groceryUtility;
    }
	 static Queue<Customer> getCustomerQueue() {
	        return customerQueue;
	    }
	 
	public static void launchGrocery(String[] args) {
		
		 if (args.length == 0 || args[0] == null || args[0].trim().isEmpty()) {
			 log.error("You need to specify a input file path !");
		        return;
		    } else {
		        String filePath = args[0];
		        Optional<GroceryMain> groceryMain = Optional.ofNullable(GroceryFileReader.parseFlatFile(filePath));
		        if(groceryMain.isPresent()) {
		        	RegisterUtility registerUtility = groceryMain.get().getRegisterUtility();
		        	int totalTime=calculateTime(registerUtility, groceryMain.get());
		        	System.out.println("Finished at: t=" + totalTime + " minutes");
		        }
		    }
	}

	public static int calculateTime(RegisterUtility registerUtility,GroceryMain groceryMain){
        int time = 1;
        while (!customerQueue.isEmpty() || registerUtility.isRegisterinService()) {
            List<Customer> customerListArrivedAtSameTime = new ArrayList<Customer>();
            GroceryHelper.collectSameTimeCustomers(customerListArrivedAtSameTime, time);
            //Customers arrived at same time are sorted first according to their item count,
            //if that is same then according to their type.
            Collections.sort(customerListArrivedAtSameTime);
            registerUtility.serviceCustomer(customerListArrivedAtSameTime);
            int index = 0;
            while (index < registerUtility.getRegisterList().size()) {
            	
                /** getting the customerList of the register and  passing it to the serve methods where the customer get served */
                Queue<Customer> customer = registerUtility.getRegisterList().get(index).getCustomerList();
                
                /** The grocery store always has a single cashier in training. This cashier is always assigned to the highest numbered register. */
                if (index == registerUtility.getRegisterList().size() - 1) {
                    GroceryHelper.traineeServe(customer);
                } else {
                    GroceryHelper.expertServe(customer);
                }
                index++;
            }
            time++;
        }
        return time;
    }
	
}
