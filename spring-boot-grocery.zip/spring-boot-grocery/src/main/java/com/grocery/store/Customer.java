package com.grocery.store;

/**
 * @author Sudesh M
 *
 */
public class Customer implements Comparable<Customer> {

	private Type type;
	
	private Integer itemCount;
	
	private int arrivalTime;
	
	private boolean inService;
	
	public Customer(Type type, int arrivalTime, Integer itemCount) {
        this.type=type;
        this.arrivalTime=arrivalTime;
        this.itemCount=itemCount;
    }
	
	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public Integer getItemCount() {
		return itemCount;
	}

	public void setItemCount(Integer itemCount) {
		this.itemCount = itemCount;
	}

	public Integer getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(Integer arrivalTime) {
		this.arrivalTime = arrivalTime;
	}
	
	public Integer servedItems(){
        return --this.itemCount;
    }
	
	public boolean isInService() {
		return inService;
	}

	public void setInService(boolean inService) {
		this.inService = inService;
	}

	/* (non-Javadoc)
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 * comparing the customers based on their item counts, if that is same
     * comparing them according to their type.
	 */
	
	public int compareTo(Customer o) {
		int val = 0;
		val = this.itemCount.compareTo(o.itemCount);
		if (val == 0) {
			val = this.type.compareTo(o.type);
		}
		return val;
	}

}

enum Type{
	A,B;
}