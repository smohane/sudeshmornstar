package com.grocery.store;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Queue;

/**
 * @author Sudesh M
 *
 */
public class RegisterUtility {

	
	private List<Register> registerList = new ArrayList<Register>();
    
    /**
     * @param registers
     */
    public RegisterUtility(int registers) {
        for (int i = 0; i < registers; i++) {
            registerList.add(new Register(i));
        }
    }
    
    public List<Register> getRegisterList() {
		return registerList;
	}

	
    /**
     * to help type A customer choose a register
     * @return
     */
    public Register getShortRegisterBySize() {
        List<Register> sortedList = new ArrayList<Register>();
        for (Register register : registerList) {
            sortedList.add(register);
        }
        Collections.sort(sortedList, Register.sizeComparator);
        return sortedList.get(0);
    }
    
   
    
    /**
     * this is specifically for type B customer which looks at the last customer of a register or
     * an empty register
     * @return
     */
    public Register getRegisterLeastItemsEnd() {
        Map<Customer,Register> custRegMap=new HashMap<Customer,Register>();
        List<Register> emptyList = new ArrayList<Register>();
        List<Customer> listWithItems = new ArrayList<Customer>();
        for (Register register : registerList) {
            if (register.getCustomerList().size() == 0) {
                emptyList.add(register);
            } else {
                Customer lastCustomer=getLastElement(register.getCustomerList());
                custRegMap.put(lastCustomer, register);
                listWithItems.add(lastCustomer);
            }
        }
        if (emptyList.size() > 0) {
            Collections.sort(emptyList);
            return emptyList.get(0);
        } else {
            Collections.sort(listWithItems);
            return custRegMap.get(listWithItems.get(0));
        }
    }
    
    
    /**
     * @param customerList
     * @return
     * to get last element of the Customer Queue.
     */
    private Customer getLastElement(Queue<Customer> customerList) {
        Customer lastCustomer=null;
        Iterator<Customer> iterator=customerList.iterator();
        while (iterator.hasNext()) {
            lastCustomer=iterator.next();
        }
        
        return lastCustomer;
    }
    
    /**
     * depending upon the type of customer and their constrains this method serves the right customer with right
     * kind of register.
     * @param customerList
     */
    public void serviceCustomer(List<Customer> customerList) {
        for (Customer customer : customerList) {
            if (customer.getType().equals(Type.A)) {
                Register shortestRegister = getShortRegisterBySize();
                shortestRegister.getCustomerList().offer(customer);
            } else {
                Register registerwithleastItems = getRegisterLeastItemsEnd();
                registerwithleastItems.getCustomerList().offer(customer);
            }
        }
    }
    
    /**
     * to check if any of the registers in the store is serving customers.
     * returns true if there are customers at any of the registers
     * false otherwise
     * @return boolean
     */
    public boolean isRegisterinService() {
        for (Register register : registerList) {
            if (register.getCustomerList().size() != 0)
                return true;
        }
        return false;
    }

}
