package com.grocery.store;

import java.util.Comparator;
import java.util.LinkedList;
import java.util.Queue;

/**
 * @author Sudesh M
 * Each Register has customers in line , to maintain this Customer queue is defined inside Register
 * Index is used to identify index of customer in queue.
 * Comparator are used to identify - smallest queue size and smallest register by index
 */
public class Register implements Comparable<Register> {

	private Queue<Customer> customerList;
    private Integer index;
    
    public Register(int index) {
        this.index = index;
        this.customerList = new LinkedList<Customer>();
    }
    
	public Queue<Customer> getCustomerList() {
		return customerList;
	}

	public Integer getIndex() {
		return index;
	}

	public int compareTo(Register o) {
		return this.index.compareTo(o.index);
	}

	public static Comparator<Register> sizeComparator = new Comparator<Register>() {
        
        public int compare(Register o1, Register o2) {
            Integer size = o1.customerList.size();
            Integer size1 = o2.customerList.size();
            return size.compareTo(size1);
        }
    };
}
