package com.grocery.store;

import java.util.List;
import java.util.Queue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * @author Sudesh M
 *
 */
public class GroceryHelper {

	private static final Logger log  = LoggerFactory.getLogger(GroceryHelper.class);
	
	static Queue<Customer> customerQueue=GroceryMain.getCustomerQueue();
	
	/**
	 * This method picks customer from the main customer queue and puts it in a separate list,which
	 * will then be sorted acording to number of items of customers and their type so that we can assign the customer
	 * with least items first. 
	 * @param  {@link Queue<Customer>}
	 * @param time
	 */
	    public static void collectSameTimeCustomers(List<Customer> customerListArrivedAtSameTime, int time) {
	        Customer customer = customerQueue.isEmpty() ? null : customerQueue.element();
	        while (customer != null && customer.getArrivalTime() == time) {
	            customerListArrivedAtSameTime.add(customerQueue.remove());
	            customer = customerQueue.isEmpty() ? null : customerQueue.element();
	        }

	    }
	    /**
	     *just keep serving the customer till it items are not empty as soon as they are empty,
	     * remove that customer from the queue.
	     * @param {@link Queue<Customer>}
	     */
	    public static void expertServe(Queue<Customer> customer) {
	        Customer cust = customer.isEmpty() ? null : customer.element();
	        if (cust != null && cust.servedItems() == 0) {
	            customer.remove();
	        }
	    }
	    /**
	     * 
	     * @param {@link Queue<Customer>}
	     */
	    public static void traineeServe(Queue<Customer> customer) {
	        Customer cust = customer.isEmpty() ? null : customer.element();
	        if (cust != null) {
	            if (!cust.isInService()) {
	                cust.setInService(true);
	            } else {
	                if (cust.servedItems() == 0) {
	                    customer.remove();
	                } else {
	                    cust.setInService(false); //to simulate double time as trainee takes double the time. 
	                }
	            }
	        }
	    }

	    
	    public static Customer buildCustomerObjects(String line) {
	        String[] items = line.split(" ");
	        if(items.length!=3){
	            log.error("Error in Input file - line --> "+line);
	            //abnormal termination
	            System.exit(-1);
	        }
	        if (items[0].equals(Type.A.toString())) {
	            return new Customer(Type.A, Integer.parseInt(items[1]),
	                    Integer.parseInt(items[2]));
	        } else if(items[0].equals(Type.B.toString())) {
	            return new Customer(Type.B, Integer.parseInt(items[1]),
	                    Integer.parseInt(items[2]));
	        }else{
	            log.error("Customer Type is Invalid");
	          //abnormal termination
	            System.exit(-1);
	            return null;
	        }
	    }
}
